# 脚本：09_04_tune_random_forest_drinking.py
# 目的：使用 GridSearch 对 "Drinking Status" 的 Random Forest 模型进行超参数优化。
# 输入：04_normalized_drinking_v2.csv（归一化后的训练数据文件，包含“Drinking Status”目标变量）
# 输出：09_04_random_forest_hyperparameters_drinking.pkl（超参数优化后的 Random Forest 模型文件））

# 导入所需的库
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV, cross_validate, StratifiedKFold
from sklearn.metrics import confusion_matrix
import joblib
import numpy as np
import time

# 9) 记录脚本开始时间
start_time = time.time()

# 1. 加载数据
# 请确保文件路径正确
file_path = r'D:\Charging\proposal20231001\after1109_rev\data\04_normalized_drinking_v2.csv'
data = pd.read_csv(file_path)

# 2. 定义目标变量和特征
target = 'Drinking Status'
features = ["Happiness", "Satisfaction", "Mood - State", "Mood - Trait", "Satisfaction with Life", "Trust",
            "Extroversion",
            "Agreeableness", "Conscientiousness", "Emotional Stability", "Intellect", "Self-esteem", "Inclusion",
            "Social Desirability", "LOT-R"]

X = data[features]
y = data[target]

# 3. 训练模型 - 使用Random Forest
rf = RandomForestClassifier(random_state=42, n_jobs=12)

# 4. 用GridSearchCV选择最佳超参数组合
param_grid = {
    'n_estimators': [100, 200, 300],
    'class_weight': [None, {0: 1, 1: 2}, {0: 1, 1: 3}, {0: 1, 1: 4}, {0: 1, 1: 10}, {0: 1, 1: 20}],
    'criterion': ['gini'],
    'max_depth': [20, 25, 30, 35, 40, 45],
    'min_samples_split': [2, 5, 10],
    'max_features': ['sqrt', 'log2']
}

grid_search = GridSearchCV(estimator=rf, param_grid=param_grid, scoring='roc_auc', cv=10, n_jobs=12, verbose=2) #这行不需要random_state

# 5. 执行网格搜索
grid_search.fit(X, y)

# 6. 打印交叉验证的结果
# 获取最佳模型
best_model = grid_search.best_estimator_

# 交叉验证
cv_results = cross_validate(best_model, X, y, cv=10, scoring=('accuracy', 'f1', 'roc_auc', 'precision', 'recall'))

# 计算平均分数
accuracy = cv_results['test_accuracy'].mean()
f1 = cv_results['test_f1'].mean()
roc_auc = cv_results['test_roc_auc'].mean()
precision = cv_results['test_precision'].mean()
recall = cv_results['test_recall'].mean()

# 打印结果
print("\n交叉验证结果：")
print(f"平均准确度: {accuracy}")
print(f"平均F1分数: {f1}")
print(f"平均AUC of ROC: {roc_auc}")
print(f"平均精度: {precision}")
print(f"平均召回率: {recall}")

# 累加混淆矩阵
total_conf_matrix = np.zeros((2, 2))
cv = StratifiedKFold(n_splits=10, random_state=42, shuffle=True)  # 确保使用相同的交叉验证分割
for train_idx, test_idx in cv.split(X, y):
    X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

    best_model.fit(X_train, y_train)
    y_pred = best_model.predict(X_test)
    conf_matrix = confusion_matrix(y_test, y_pred)
    total_conf_matrix += conf_matrix

# 打印混淆矩阵
tn, fp, fn, tp = total_conf_matrix.ravel()
print("\n总体混淆矩阵：")
print(f"TP: {tp} | FP: {fp}")
print(f"FN: {fn} | TN: {tn}")

# 7. 打印模型配置
print("\n模型配置参数：")
for param, value in best_model.get_params().items():
    print(f"{param}: {value}")

# 8. 保存最佳模型
model_save_path = r'D:\Charging\proposal20231001\after1109_rev\models\tuned_models\09_04_random_forest_hyperparameters_drinking.pkl'
joblib.dump(best_model, model_save_path)

# 输出保存路径
print(f"\n模型已保存到：{model_save_path}")

# 9) 计算并打印脚本运行所需的总时间
end_time = time.time()
print(f"\n脚本运行总时间: {end_time - start_time} 秒")