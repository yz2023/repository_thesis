# 脚本：09_05_tune_SVM_drinking.py
# 目的：使用 GridSearch 对 "Drinking Status" 的 Support Vector Machine 模型进行超参数优化。
# 输入：04_normalized_drinking_v2.csv（归一化后的训练数据文件，包含“Drinking Status”目标变量）
# 输出：09_05_SVM_hyperparameters_drinking.pkl（超参数优化后的 Support Vector Machine 模型文件））


import pandas as pd
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, precision_score, recall_score, confusion_matrix
import joblib
import time

# 9) 记录脚本开始时间
start_time = time.time()

# 1）加载数据
file_path = "D:/Charging/proposal20231001/after1109_rev/data/04_normalized_drinking_v2.csv"
data = pd.read_csv(file_path)

# 2）定义目标变量和特征
target = "Drinking Status"
features = ["Happiness", "Satisfaction", "Mood - State", "Mood - Trait", "Satisfaction with Life",
            "Trust", "Extroversion", "Agreeableness", "Conscientiousness", "Emotional Stability",
            "Intellect", "Self-esteem", "Inclusion", "Social Desirability", "LOT-R"]

X = data[features]
y = data[target]

# 3）训练模型：使用支持向量机
svm = SVC(kernel='rbf', random_state=42)

# 4）使用GridSearchCV选择最佳超参数组合
param_grid = {
    'C': [0.1, 1, 10, 50, 100, 1000],
    'gamma': [0.01, 0.1, 0.5, 1, 10]
}
grid_search = GridSearchCV(svm, param_grid, scoring='roc_auc', n_jobs=12, cv=10)

# 5）执行网格搜索
grid_search.fit(X, y)

# 6）打印交叉验证的结果
best_model = grid_search.best_estimator_
y_pred = best_model.predict(X)

# 计算并打印评估指标
print(f"平均准确率: {accuracy_score(y, y_pred)}")
print(f"平均F1分数: {f1_score(y, y_pred)}")
print(f"AUC of ROC: {roc_auc_score(y, y_pred)}")
print(f"平均精确率: {precision_score(y, y_pred)}")
print(f"平均召回率: {recall_score(y, y_pred)}")

# 计算混淆矩阵
conf_matrix = confusion_matrix(y, y_pred)
tn, fp, fn, tp = conf_matrix.ravel()
print("\n总体混淆矩阵：")
print(f"TP: {tp} | FP: {fp}")
print(f"FN: {fn} | TN: {tn}")

# 7）打印模型配置
print("\n模型配置参数：")
for param, value in best_model.get_params().items():
    print(f"{param}: {value}")

# 8）保存模型
model_save_path = "D:/Charging/proposal20231001/after1109_rev/models/tuned_models/09_05_SVM_hyperparameters_drinking.pkl"
joblib.dump(best_model, model_save_path)

# 9) 计算并打印脚本运行所需的总时间
end_time = time.time()
print(f"\n脚本运行总时间: {end_time - start_time} 秒")
