# 脚本：02_missing_data_imputation_train.py
# 目的：对训练数据进行多重插补处理，生成没有缺失值的新数据集，并训练缺失值模型。
# 输入：01_train_data.csv（训练集文件）
# 输出：02_imputed_train_data.csv（插补后的训练数据文件）
# 模型输出：missing_data_model.pkl（缺失值模型文件）


# 以上指令中的问题：
# self-esteem中的0

import pandas as pd
import numpy as np
from sklearn.impute import IterativeImputer
import random
import pickle

# 设置随机种子以保证可复现性
random_seed = 42
random.seed(random_seed)
np.random.seed(random_seed)

# 加载数据
file_path = 'D:/Charging/proposal20231001/after1109_rev/data/01_train_data.csv'
data = pd.read_csv(file_path)


# 检查整个数据集，把值为-9的数替换为NaN
data = data.replace(-9, np.nan)

# 应用多重插补，这里使用 IterativeImputer
imputer = IterativeImputer(random_state=random_seed, max_iter=10, initial_strategy='mean')

# 对于插补，我们将只选择数值列
numeric_columns = data.select_dtypes(include=[np.number]).columns
data_numeric = data[numeric_columns]

# 使用imputer进行插补
data_imputed = imputer.fit_transform(data_numeric)

# 四舍五入插补后的数据以确保所有值都是整数
data_imputed_rounded = np.round(data_imputed)

# 将插补后的数据放回原来的DataFrame中
data[numeric_columns] = data_imputed_rounded

# 保存插补后的数据集
output_file_path = 'D:/Charging/proposal20231001/after1109_rev/data/02_imputed_train_data.csv'
data.to_csv(output_file_path, index=False)

# 保存插补模型，以便将来可能的使用
model_file_path = 'D:/Charging/proposal20231001/after1109_rev/models/missing_data_model.pkl'
with open(model_file_path, 'wb') as file:
    pickle.dump(imputer, file)


