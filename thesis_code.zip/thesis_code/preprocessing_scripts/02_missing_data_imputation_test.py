# 脚本：02_missing_data_imputation_test.py
# 目的：对测试集进行缺失值插补，使用已训练好的缺失值模型，生成新的测试集数据文件。
# 输入：01_test_data.csv（测试集文件）
# 输入模型：missing_data_model.pkl（已训练好的缺失值模型文件）
# 输出：02_imputed_test_data.csv（插补后的测试集文件）



import pandas as pd
import numpy as np
import pickle

# 设置文件路径
input_file_path = 'D:/Charging/proposal20231001/after1109_rev/data/01_test_data.csv'
output_file_path = 'D:/Charging/proposal20231001/after1109_rev/data/02_imputed_test_data.csv'
model_file_path = 'D:/Charging/proposal20231001/after1109_rev/models/missing_data_model.pkl'

# 读取输入文件
df = pd.read_csv(input_file_path)

# 检查整个数据集，把数据集中值为-9的数，替换为NaN
df = df.replace(-9, np.nan)

# 加载缺失值模型
with open(model_file_path, 'rb') as file:
    missing_data_model = pickle.load(file)

# 应用模型插补缺失值，并确保插补的值为整数
# 需要注意的是，插补模型的输出可能是浮点数，我们需要将其转换为整数
imputed_data_float = missing_data_model.transform(df)
imputed_data_int = np.rint(imputed_data_float).astype(int)  # 四舍五入并转换为整数
imputed_data = pd.DataFrame(imputed_data_int, columns=df.columns)

# 保存插补后的数据集
imputed_data.to_csv(output_file_path, index=False)

# 打印新文件的存储路径
print("新的插补后的数据集已经保存到：", output_file_path)