# 脚本：01_data_splitting.py
# 目的：将数据集拆分为训练集和测试集。
# 输入：00_simplified_data_v1.csv（移除列后的数据文件）
# 输出：01_train_data.csv（训练集文件）、01_test_data.csv（测试集文件）


import pandas as pd
from sklearn.model_selection import train_test_split

# 文件路径配置
input_path = 'D:/Charging/proposal20231001/after1109_rev/data/00_simplified_data_v1.csv'
output_dir = 'D:/Charging/proposal20231001/after1109_rev/data/'

# 加载数据
data = pd.read_csv(input_path)

# 分层抽样
# 这里我们使用'Smoking Status'和'Drinking Status'列进行分层，确保训练集和测试集在这两个特征上的分布一致
# 需要根据这两列创建一个新的列来作为分层的依据
data['stratify_on'] = data['Smoking Status'].astype(str) + "-" + data['Drinking Status'].astype(str)

# 划分数据集，训练集占80%，测试集占20%
# 加入随机种子random_state = 42
train_data, test_data = train_test_split(data, test_size=0.2, stratify=data['stratify_on'], random_state=42)

# 移除辅助用的'stratify_on'列
train_data = train_data.drop('stratify_on', axis=1)
test_data = test_data.drop('stratify_on', axis=1)

# 保存训练集和测试集到CSV文件
train_data.to_csv(output_dir + '01_train_data.csv', index=False)
test_data.to_csv(output_dir + '01_test_data.csv', index=False)

# 返回生成的文件路径
output_train_path = output_dir + '01_train_data.csv'
output_test_path = output_dir + '01_test_data.csv'



