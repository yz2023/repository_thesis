# 脚本：03_oversampling_smoking.py
# 目的：过采样处理已处理好缺失值的训练集（包含“Smoking Status”目标变量），以解决类别不平衡问题，并生成新的数据文件。
# 输入：02_imputed_train_smoking.csv（插补后的训练数据文件，包含“Smoking Status”目标变量）
# 输出：03_oversampled_smoking.csv（过采样后的训练数据文件，包含“Smoking Status”目标变量）


import pandas as pd
from imblearn.over_sampling import SMOTE

# 加载数据
input_file_path = "D:\\Charging\\proposal20231001\\after1109_rev\\data\\02_imputed_train_smoking.csv"
data = pd.read_csv(input_file_path)

# 打印出 "Unnamed: 0" 列和 "nomem_encr" 列的最大索引值
print("Unnamed: 0 最大索引值:", data["Unnamed: 0"].max())
print("nomem_encr 最大索引值:", data["nomem_encr"].max())

# 定义特征和目标变量
features = ["Happiness", "Satisfaction", "Mood - State", "Mood - Trait", "Satisfaction with Life",
            "Trust", "Extroversion", "Agreeableness", "Conscientiousness", "Emotional Stability",
            "Intellect", "Self-esteem", "Inclusion", "Social Desirability", "LOT-R"]
target = "Smoking Status"

# 应用SMOTE
sm = SMOTE(random_state=42)
X_resampled, y_resampled = sm.fit_resample(data[features], data[target])

# 将结果转换为整数
X_resampled = X_resampled.round(0).astype(int)
y_resampled = y_resampled.astype(int)

# 为 "Unnamed: 0" 列和 "nomem_encr" 列生成新索引
max_unnamed = int(data["Unnamed: 0"].max())  # 确保是整数
max_nomem_encr = int(data["nomem_encr"].max())  # 确保是整数
additional_indices = len(X_resampled) - len(data)
new_indices_unnamed = range(max_unnamed + 1, max_unnamed + 1 + additional_indices)
new_indices_nomem_encr = range(max_nomem_encr + 1, max_nomem_encr + 1 + additional_indices)

# 创建新的 DataFrame 并添加新索引
oversampled_data = pd.DataFrame(X_resampled, columns=features)
oversampled_data[target] = y_resampled
oversampled_data["Unnamed: 0"] = list(data["Unnamed: 0"]) + list(new_indices_unnamed)
oversampled_data["nomem_encr"] = list(data["nomem_encr"]) + list(new_indices_nomem_encr)

# 调整列的顺序以匹配原始数据
final_column_order = ["Unnamed: 0", "nomem_encr"] + features + [target]
oversampled_data = oversampled_data[final_column_order]

# 保存过采样后的数据
output_file_path = "D:\\Charging\\proposal20231001\\after1109_rev\\data\\03_oversampled_smoking.csv"
oversampled_data.to_csv(output_file_path, index=False)
