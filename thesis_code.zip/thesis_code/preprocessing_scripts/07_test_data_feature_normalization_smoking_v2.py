# 脚本：07_test_data_feature_normalization_smoking_v2.py
# 目的：对已处理好的训练数据中的15个特征进行归一化，以确保它们具有相似的尺度。
# 输入：06_imputed_test_smoking.csv（过采样后的训练数据文件，包含“Smoking Status”目标变量）
# 输入归一化处理器：D:\\Charging\\proposal20231001\\after1109_rev\\models\\min_max_scaler_smoking.pkl
# 输出：07_normalized_test_smoking_v2.csv（归一化后的训练数据文件，包含“Smoking Status”目标变量）


import pandas as pd
import joblib

# 文件路径
input_file = r"D:\Charging\proposal20231001\after1109_rev\data\06_imputed_test_smoking.csv"
output_file = r"D:\Charging\proposal20231001\after1109_rev\data\07_normalized_test_smoking_v2.csv"
scaler_file = r"D:\Charging\proposal20231001\after1109_rev\models\min_max_scaler_smoking.pkl"

# 读取测试数据
df = pd.read_csv(input_file)

# 定义需要进行归一化处理的特征
features = ["Happiness", "Satisfaction", "Mood - State", "Mood - Trait", "Satisfaction with Life", "Trust",
            "Extroversion", "Agreeableness", "Conscientiousness", "Emotional Stability", "Intellect",
            "Self-esteem", "Inclusion", "Social Desirability", "LOT-R"]

# 加载归一化处理器
scaler = joblib.load(scaler_file)

# 对特征进行归一化处理
df[features] = scaler.transform(df[features])

# 保存处理后的数据集
df.to_csv(output_file, index=False)

