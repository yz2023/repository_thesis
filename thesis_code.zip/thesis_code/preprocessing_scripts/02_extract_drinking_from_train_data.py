# 脚本：02_extract_drinking_from_train_data.py
# 目的：从插补后的训练数据中提取并保留“Drinking Status”作为目标变量。
# 输入：02_imputed_train_data.csv（插补后的训练数据文件）
# 输出：02_drinking_target_train_data.csv（仅包含“Smoking Status”的训练数据文件）

import pandas as pd

# 载入数据
input_path = 'D:/Charging/proposal20231001/after1109_rev/data/02_imputed_train_data.csv'
data = pd.read_csv(input_path)

# 删除 "Smoking Status" 这一列
data.drop('Smoking Status', axis=1, inplace=True)

# 保存新的 .csv 文件
output_path = 'D:/Charging/proposal20231001/after1109_rev/data/02_imputed_train_drinking.csv'
data.to_csv(output_path, index=False)
