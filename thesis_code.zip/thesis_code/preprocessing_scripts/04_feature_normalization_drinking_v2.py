# 脚本：04_feature_normalization_drinking_v2.py
# 目的：对已处理好的训练数据中的15个特征进行归一化，以确保它们具有相似的尺度。
# 输入：03_oversampled_drinking.csv（过采样后的训练数据文件，包含“Drinking Status”目标变量）
# 输出：04_normalized_drinking_v2.csv（归一化后的训练数据文件，包含“Drinking Status”目标变量）


import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# 文件路径
input_file = r"D:\Charging\proposal20231001\after1109_rev\data\03_oversampled_drinking.csv"
output_file = r"D:\Charging\proposal20231001\after1109_rev\data\04_normalized_drinking_v2.csv"
scaler_file = r"D:\Charging\proposal20231001\after1109_rev\models\min_max_scaler_drinking.pkl"

# 读取数据
df = pd.read_csv(input_file)

# 定义二分类问题的特征
features = ["Happiness", "Satisfaction", "Mood - State", "Mood - Trait", "Satisfaction with Life", "Trust",
            "Extroversion", "Agreeableness", "Conscientiousness", "Emotional Stability", "Intellect",
            "Self-esteem", "Inclusion", "Social Desirability", "LOT-R"]

# 归一化处理
scaler = MinMaxScaler()
df[features] = scaler.fit_transform(df[features])

# 保存归一化处理器
import joblib
joblib.dump(scaler, scaler_file)

# 保存处理后的数据集
df.to_csv(output_file, index=False)

