# 脚本：06_extract_smoking_from_test_data.py
# 目的：从插补后的测试数据中提取并保留“Smoking Status”作为目标变量。
# 输入：02_imputed_test_data.csv（插补后的训练数据文件）
# 输出：06_imputed_test_smoking.csv（仅包含“Smoking Status”的测试数据文件）

import pandas as pd

# 载入数据
input_path = 'D:/Charging/proposal20231001/after1109_rev/data/02_imputed_test_data.csv'
data = pd.read_csv(input_path)

# 删除 "Drinking Status" 这一列
data.drop('Drinking Status', axis=1, inplace=True)

# 保存新的 .csv 文件
output_path = 'D:/Charging/proposal20231001/after1109_rev/data/06_imputed_test_smoking.csv'
data.to_csv(output_path, index=False)

output_path # 输出新文件的路径