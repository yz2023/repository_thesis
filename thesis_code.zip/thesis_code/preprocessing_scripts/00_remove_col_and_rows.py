# 脚本：00_remove_col_and_rows.py
# 目的：从数据集中移除指定的列并进行数据筛选，生成新的数据文件。
# 输入：00_simplified_data_v0.csv（原始数据文件）
# 输出：00_simplified_data_v1.csv（移除列和行后的数据文件)


import pandas as pd

# 加载 CSV 文件到 pandas 的 DataFrame
file_path = 'D:/Charging/proposal20231001/after1109_rev/data/00_simplified_data_v0.csv'
data = pd.read_csv(file_path)

# 删除 'cp23o_m' 列
data.drop('cp23o_m', axis=1, inplace=True)

# 删除所有特定列同时为0的行
columns_to_check = ["Extroversion", "Agreeableness", "Conscientiousness", "Emotional Stability", "Intellect"]
data = data[~(data[columns_to_check] == 0).all(axis=1)]

# 删除同时满足"Inclusion"为缺失值，且"Social Desirability"和"LOT-R"的值都为0的行
data = data[~(data['Inclusion'].isna() & (data['Social Desirability'] == 0) & (data['LOT-R'] == 0))]

# 定义新文件的路径
new_file_path = 'D:/Charging/proposal20231001/after1109_rev/data/00_simplified_data_v1.csv'

# 将修改后的 DataFrame 保存到新的 CSV 文件，不包含索引
data.to_csv(new_file_path, index=False)
