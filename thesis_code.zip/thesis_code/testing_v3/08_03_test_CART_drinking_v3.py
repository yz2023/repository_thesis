# 脚本：08_03_test_CART_drinking_v3.py
# 目的：使用训练好的 CART 模型对测试集进行测试，以评估其在针对 "Drinking Status" 的分类任务上的性能。
# 输入模型：06_03_CART_model_drinking_v3.pkl（训练好的 CART 模型文件）
# 输入测试数据：07_normalized_test_drinking_v2.csv（测试数据文件，针对 "Drinking Status"）
# 输出文件：08_03_test_results_CART_drinking_v3.csv（测试结果文件）


import pandas as pd
from joblib import load
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, precision_score, recall_score, confusion_matrix

# 路径设置
test_data_path = "D:\\Charging\\proposal20231001\\after1109_rev\\data\\07_normalized_test_drinking_v2.csv"
model_path = "D:\\Charging\\proposal20231001\\after1109_rev\\models\\trained_models_v3\\06_03_CART_model_drinking_v3.pkl"
results_path = "D:\\Charging\\proposal20231001\\after1109_rev\\results\\08_03_test_results_CART_drinking_v3.csv"

# 加载测试数据
test_data = pd.read_csv(test_data_path)

# 选择特征列
feature_columns = ["Happiness", "Satisfaction", "Mood - State", "Mood - Trait", "Satisfaction with Life", "Trust",
                   "Extroversion", "Agreeableness", "Conscientiousness", "Emotional Stability", "Intellect",
                   "Self-esteem", "Inclusion", "Social Desirability", "LOT-R"]

# 提取特征和目标变量
X_test = test_data[feature_columns]
y_test = test_data["Drinking Status"]

# 加载模型
model = load(model_path)

# 进行预测
y_pred = model.predict(X_test)

# 计算评价指标
accuracy = accuracy_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)
roc_auc = roc_auc_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
conf_matrix = confusion_matrix(y_test, y_pred)

# 打印评价指标
print(f"Accuracy: {accuracy}")
print(f"F1 Score: {f1}")
print(f"AUC of ROC: {roc_auc}")
print(f"Precision: {precision}")
print(f"Recall: {recall}")

# 打印总体混淆矩阵
tn, fp, fn, tp = conf_matrix.ravel()
print("\n总体混淆矩阵：")
print(f"TP: {tp} | FP: {fp}")
print(f"FN: {fn} | TN: {tn}")

# 将预测结果保存到文件
test_data["Predicted Smoking Status"] = y_pred
test_data.to_csv(results_path, index=False)

