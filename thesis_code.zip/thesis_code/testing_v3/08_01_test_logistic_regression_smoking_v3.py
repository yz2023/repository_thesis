# 脚本：08_01_test_logistic_regression_smoking_v3.py
# 目的：使用训练好的 Logistic Regression 模型对测试集进行测试，以评估其在针对 "Smoking Status" 的分类任务上的性能。
# 输入模型：06_01_logistic_regression_model_smoking_v3.pkl（训练好的 Logistic Regression 模型文件）
# 输入测试数据：07_normalized_test_smoking_v2.csv（测试数据文件，针对 "Smoking Status"）
# 输出文件：08_01_test_results_logistic_regression_smoking_v3.csv（测试结果文件）


import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, precision_score, recall_score, confusion_matrix
import joblib

# 加载测试数据
test_data_path = "D:\\Charging\\proposal20231001\\after1109_rev\\data\\07_normalized_test_smoking_v2.csv"
test_data = pd.read_csv(test_data_path)

# 选取特征和目标变量
features = ["Happiness", "Satisfaction", "Mood - State", "Mood - Trait", "Satisfaction with Life",
            "Trust", "Extroversion", "Agreeableness", "Conscientiousness", "Emotional Stability",
            "Intellect", "Self-esteem", "Inclusion", "Social Desirability", "LOT-R"]
X_test = test_data[features]
y_test = test_data["Smoking Status"]

# 加载模型
model_path = "D:\\Charging\\proposal20231001\\after1109_rev\\models\\trained_models_v3\\06_01_logistic_regression_model_smoking_v3.pkl"
model = joblib.load(model_path)

# 使用模型进行预测
predictions = model.predict(X_test)

# 计算性能指标
accuracy = accuracy_score(y_test, predictions)
f1 = f1_score(y_test, predictions)
auc = roc_auc_score(y_test, model.predict_proba(X_test)[:, 1])
precision = precision_score(y_test, predictions)
recall = recall_score(y_test, predictions)
conf_matrix = confusion_matrix(y_test, predictions)

# 打印性能指标
print("Accuracy:", accuracy)
print("F1 Score:", f1)
print("AUC of ROC:", auc)
print("Precision:", precision)
print("Recall:", recall)

# 打印总体混淆矩阵
tn, fp, fn, tp = conf_matrix.ravel()
print("\n总体混淆矩阵：")
print(f"TP: {tp} | FP: {fp}")
print(f"FN: {fn} | TN: {tn}")

# 保存预测结果
results_path = "D:\\Charging\\proposal20231001\\after1109_rev\\results\\08_01_test_results_logistic_regression_smoking_v3.csv"
test_data["Predicted Smoking Status"] = predictions
test_data.to_csv(results_path, index=False)

