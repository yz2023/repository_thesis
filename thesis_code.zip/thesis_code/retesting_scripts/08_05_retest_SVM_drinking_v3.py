# 脚本：08_05_retest_SVM_drinking_v3.py
# 目的：使用训练好的 Support Vector Machine 模型对测试集进行测试，以评估其在针对 "Drinking Status" 的分类任务上的性能。
# 输入模型：09_05_SVM_hyperparameters_drinking.pkl（调参后的 Support Vector Machine 模型文件）
# 输入测试数据：07_normalized_test_drinking_v2.csv（测试数据文件，针对 "Drinking Status"）
# 输出文件：08_05_retest_results_SVM_drinking_v3.csv（重新测试的结果文件）


import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.metrics import precision_score, recall_score, confusion_matrix
import joblib

# 数据和模型的路径
test_data_path = "D:\\Charging\\proposal20231001\\after1109_rev\\data\\07_normalized_test_drinking_v2.csv"
model_path = "D:\\Charging\\proposal20231001\\after1109_rev\\models\\tuned_models\\09_05_SVM_hyperparameters_drinking.pkl"
results_path = "D:\\Charging\\proposal20231001\\after1109_rev\\results\\08_05_retest_results_SVM_drinking_v3.csv"

# 加载测试数据
data = pd.read_csv(test_data_path)

# 提取特征和目标变量
features = data[["Happiness", "Satisfaction", "Mood - State", "Mood - Trait",
                 "Satisfaction with Life", "Trust", "Extroversion", "Agreeableness",
                 "Conscientiousness", "Emotional Stability", "Intellect",
                 "Self-esteem", "Inclusion", "Social Desirability", "LOT-R"]]
target = data["Drinking Status"]

# 加载模型
model = joblib.load(model_path)

# 进行预测
predictions = model.predict(features)

# 保存预测结果
results = data.copy()
results["Predictions"] = predictions
results.to_csv(results_path, index=False)

# 计算性能指标
accuracy = accuracy_score(target, predictions)
f1 = f1_score(target, predictions)
roc_auc = roc_auc_score(target, predictions)
precision = precision_score(target, predictions)
recall = recall_score(target, predictions)
conf_matrix = confusion_matrix(target, predictions)

# 打印性能指标
print("Accuracy:", accuracy)
print("F1 Score:", f1)
print("ROC AUC:", roc_auc)
print("Precision:", precision)
print("Recall:", recall)

# 打印总体混淆矩阵
tn, fp, fn, tp = conf_matrix.ravel()
print("\n总体混淆矩阵：")
print(f"TP: {tp} | FP: {fp}")
print(f"FN: {fn} | TN: {tn}")

