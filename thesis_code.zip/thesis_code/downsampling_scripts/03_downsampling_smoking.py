
# 导入必要的库
import pandas as pd

# 加载数据
input_file_path = "D:\\Charging\\proposal20231001\\rq2_d\\data\\02_imputed_train_smoking.csv"
data = pd.read_csv(input_file_path)

# 定义特征和目标变量
features = ["Happiness", "Satisfaction", "Mood - State", "Mood - Trait", "Satisfaction with Life",
            "Trust", "Extroversion", "Agreeableness", "Conscientiousness", "Emotional Stability",
            "Intellect", "Self-esteem", "Inclusion", "Social Desirability", "LOT-R", "Gender", "Age Category",
            "Household Number", "Income Category", "Education Level", "Relationship with Family", "Have Partner"]
target = "Smoking Status"

# 分离出不同类别
class_counts = data[target].value_counts()
min_class = class_counts.idxmin()
min_class_count = class_counts.min()

# 对多数类进行下采样
data_min_class = data[data[target] == min_class]
data_maj_class = data[data[target] != min_class].sample(n=min_class_count, random_state=42)

# 合并数据集并打乱顺序
downsampled_data = pd.concat([data_min_class, data_maj_class]).sample(frac=1, random_state=42)

# 保存下采样后的数据
output_file_path = "D:\\Charging\\proposal20231001\\rq2_d\\data\\03_downsampled_smoking.csv"
downsampled_data.to_csv(output_file_path, index=False)
