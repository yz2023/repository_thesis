# 脚本：06_03_train_CART_smoking_v3.py
# 目的：使用 CART 模型训练针对 "Smoking Status" 的分类任务。
# 输入：04_normalized_smoking_v2.csv（归一化后的训练数据文件，包含“Smoking Status”目标变量）
# 输出：06_03_CART_model_smoking_v3.pkl（训练好的 CART 模型文件）


import pandas as pd
from sklearn.model_selection import cross_val_predict, KFold
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, confusion_matrix, precision_score, recall_score
import joblib
import numpy as np

# 1）加载数据
file_path = 'D:\\Charging\\proposal20231001\\after1109_rev\\data\\04_normalized_smoking_v2.csv'
data = pd.read_csv(file_path)

# 2）定义目标变量和特征
target = 'Smoking Status'
features = ["Happiness", "Satisfaction", "Mood - State", "Mood - Trait", "Satisfaction with Life", "Trust", "Extroversion",
            "Agreeableness", "Conscientiousness", "Emotional Stability", "Intellect", "Self-esteem", "Inclusion",
            "Social Desirability", "LOT-R"]

X = data[features]
y = data[target]

# 3）训练模型（添加了随机种子）
model = DecisionTreeClassifier(random_state=42)
model.fit(X, y)

# 保存模型
model_file = 'D:\\Charging\\proposal20231001\\after1109_rev\\models\\trained_models_v3\\06_03_CART_model_smoking_v3.pkl'
joblib.dump(model, model_file)

# 4）交叉验证（使用相同的随机种子）
kf = KFold(n_splits=10, shuffle=True, random_state=42)

# 初始化评分记录
accuracy_scores = []
f1_scores = []
roc_auc_scores = []
conf_matrix = []
precision_scores = []
recall_scores = []

# 进行k-fold交叉验证
for train_index, test_index in kf.split(X):
    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]

    # 使用相同的随机种子重新训练模型
    model = DecisionTreeClassifier(random_state=42)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    # 计算各种评分
    accuracy_scores.append(accuracy_score(y_test, predictions))
    f1_scores.append(f1_score(y_test, predictions))
    roc_auc_scores.append(roc_auc_score(y_test, predictions))
    conf_matrix.append(confusion_matrix(y_test, predictions))
    precision_scores.append(precision_score(y_test, predictions))
    recall_scores.append(recall_score(y_test, predictions))

# 5）打印交叉验证的结果
print("Average Accuracy:", sum(accuracy_scores) / len(accuracy_scores))
print("Average F1 Score:", sum(f1_scores) / len(f1_scores))
print("Average AUC of ROC:", sum(roc_auc_scores) / len(roc_auc_scores))
# print("Confusion Matrix:\n", sum(conf_matrix))
print("Average Precision:", sum(precision_scores) / len(precision_scores))
print("Average Recall:", sum(recall_scores) / len(recall_scores))

# 求和混淆矩阵
total_conf_matrix = np.sum(conf_matrix, axis=0)
tn, fp, fn, tp = total_conf_matrix.ravel()
print("\n总体混淆矩阵：")
print(f"TP: {tp} | FP: {fp}")
print(f"FN: {fn} | TN: {tn}")

# 6) 打印模型配置
print("\nModel Configuration:")
for param, value in model.get_params().items():
    print(f"{param}: {value}")

