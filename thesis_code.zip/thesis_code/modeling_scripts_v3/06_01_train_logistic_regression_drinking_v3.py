# 脚本：06_01_train_logistic_regression_drinking_v3.py
# 目的：使用 Logistic Regression 模型训练针对 "Drinking Status" 的分类任务。
# 输入：04_normalized_drinking_v2.csv（归一化后的训练数据文件，包含“Drinking Status”目标变量）
# 输出：06_01_logistic_regression_model_drinking_v3.pkl（训练好的 Logistic Regression 模型文件）


import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, confusion_matrix, precision_score, recall_score
import joblib
import numpy as np

# 1）加载数据
file_path = 'D:\\Charging\\proposal20231001\\after1109_rev\\data\\04_normalized_drinking_v2.csv'
data = pd.read_csv(file_path)

# 2）定义目标变量和特征
target = 'Drinking Status'
features = ["Happiness", "Satisfaction", "Mood - State", "Mood - Trait", "Satisfaction with Life", "Trust", "Extroversion", "Agreeableness", "Conscientiousness", "Emotional Stability", "Intellect", "Self-esteem", "Inclusion", "Social Desirability", "LOT-R"]
X = data[features]
y = data[target]

# 3）训练模型
model = LogisticRegression()
model.fit(X, y)

# 保存模型
model_path = 'D:\\Charging\\proposal20231001\\after1109_rev\\models\\trained_models_v3\\06_01_logistic_regression_model_drinking_v3.pkl'
joblib.dump(model, model_path)

# 4）交叉验证
kf = KFold(n_splits=10, random_state=42, shuffle=True)
accuracy_scores, f1_scores, roc_auc_scores = [], [], []
precision_scores, recall_scores = [], []
total_confusion_matrix = np.zeros((2, 2))

for train_index, test_index in kf.split(X):
    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]

    model = LogisticRegression()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)[:, 1]

    accuracy_scores.append(accuracy_score(y_test, y_pred))
    f1_scores.append(f1_score(y_test, y_pred))
    roc_auc_scores.append(roc_auc_score(y_test, y_pred_proba))
    precision_scores.append(precision_score(y_test, y_pred))
    recall_scores.append(recall_score(y_test, y_pred))
    total_confusion_matrix += confusion_matrix(y_test, y_pred)  # 累加混淆矩阵

# 5）交叉验证结果
print(f'Accuracy: {np.mean(accuracy_scores)}')
print(f'F1 Score: {np.mean(f1_scores)}')
print(f'AUC of ROC: {np.mean(roc_auc_scores)}')
print(f'Precision: {np.mean(precision_scores)}')
print(f'Recall: {np.mean(recall_scores)}')

# 打印总体混淆矩阵
tn, fp, fn, tp = total_confusion_matrix.ravel()
print("\n总体混淆矩阵：")
print(f"TP: {tp} | FP: {fp}")
print(f"FN: {fn} | TN: {tn}")

# 6) 模型配置
print("\n模型配置参数：")
for key, value in model.get_params().items():
    print(f'{key}: {value}')

# 7) 模型系数
print("\n特征系数：")
coef = model.coef_[0]
for i, feature in enumerate(features):
    print(f'{feature}: {coef[i]}')
print(f'截距: {model.intercept_[0]}')

# 打印模型公式
print("\n逻辑回归模型公式：")
formula = "y = 1 / (1 + exp(-(" + str(model.intercept_[0])
for i, feature in enumerate(features):
    formula += f" + ({coef[i]} * {feature})"
formula += ")))"
print(formula)

