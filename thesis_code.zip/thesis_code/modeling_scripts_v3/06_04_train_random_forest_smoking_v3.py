# 脚本：06_04_train_random_forest_smoking_v3.py
# 目的：使用 Random Forest 模型训练针对 "Smoking Status" 的分类任务。
# 输入：04_normalized_smoking_v2.csv（归一化后的训练数据文件，包含“Smoking Status”目标变量）
# 输出：06_04_random_forest_model_smoking_v3.pkl（训练好的 Random Forest 模型文件）


import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score, cross_validate, KFold
from sklearn.metrics import confusion_matrix, make_scorer, accuracy_score, f1_score, roc_auc_score, precision_score, recall_score
import numpy as np
import joblib

# 1) 加载数据
file_path = 'D:\\Charging\\proposal20231001\\after1109_rev\\data\\04_normalized_smoking_v2.csv'
data = pd.read_csv(file_path)

# 2) 定义目标变量和特征
target = 'Smoking Status'
features = ["Happiness", "Satisfaction", "Mood - State", "Mood - Trait", "Satisfaction with Life", "Trust",
            "Extroversion", "Agreeableness", "Conscientiousness", "Emotional Stability", "Intellect", "Self-esteem",
            "Inclusion", "Social Desirability", "LOT-R"]

X = data[features]
y = data[target]

# 3) 训练模型
model = RandomForestClassifier(random_state=42)
model.fit(X, y)
# 保存模型
joblib.dump(model, 'D:\\Charging\\proposal20231001\\after1109_rev\\models\\trained_models_v3\\06_04_random_forest_model_smoking_v3.pkl')

# 4) 交叉验证
kf = KFold(n_splits=10, random_state=42, shuffle=True)

# 5) 计算交叉验证的结果
scoring = {'accuracy': make_scorer(accuracy_score),
           'f1_score': make_scorer(f1_score),
           'roc_auc': make_scorer(roc_auc_score),
           'precision': make_scorer(precision_score),
           'recall': make_scorer(recall_score)}

cv_results = cross_validate(model, X, y, cv=kf, scoring=scoring)
print("Accuracy:", np.mean(cv_results['test_accuracy']))
print("F1 Score:", np.mean(cv_results['test_f1_score']))
print("AUC of ROC:", np.mean(cv_results['test_roc_auc']))
print("Precision:", np.mean(cv_results['test_precision']))
print("Recall:", np.mean(cv_results['test_recall']))

# 计算混淆矩阵
conf_matrix = np.zeros((2, 2))
for train_index, test_index in kf.split(X):
    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    conf_matrix += confusion_matrix(y_test, predictions)

# 打印总体混淆矩阵
tn, fp, fn, tp = conf_matrix.ravel()
print("\n总体混淆矩阵：")
print(f"TP: {tp} | FP: {fp}")
print(f"FN: {fn} | TN: {tn}")

# 6) 模型配置
print("\nModel Configuration Parameters:")
for param, value in model.get_params().items():
    print(f"{param}: {value}")

max_depths = [tree.tree_.max_depth for tree in model.estimators_]

# 打印最大深度、最小深度和平均深度
print(f"最大深度: {max(max_depths)}")
print(f"最小深度: {min(max_depths)}")
print(f"平均深度: {sum(max_depths) / len(max_depths)}")

