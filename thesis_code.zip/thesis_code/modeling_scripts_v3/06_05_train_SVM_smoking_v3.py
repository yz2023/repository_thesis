# 脚本：06_05_train_SVM_smoking_v3.py
# 目的：使用 Support Vector Machine 模型训练针对 "Smoking Status" 的分类任务。
# 输入：04_normalized_smoking_v2.csv（归一化后的训练数据文件，包含“Smoking Status”目标变量）
# 输出：06_05_SVM_model_smoking_v3.pkl（训练好的 Support Vector Machine 模型文件）


import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, confusion_matrix, precision_score, recall_score
import numpy as np
import joblib

# 1. 加载数据
file_path = "D:\\Charging\\proposal20231001\\after1109_rev\\data\\04_normalized_smoking_v2.csv"
data = pd.read_csv(file_path)

# 2. 定义目标变量和特征
target_variable = "Smoking Status"
features = ["Happiness", "Satisfaction", "Mood - State", "Mood - Trait", "Satisfaction with Life", "Trust",
            "Extroversion", "Agreeableness", "Conscientiousness", "Emotional Stability", "Intellect",
            "Self-esteem", "Inclusion", "Social Desirability", "LOT-R"]

X = data[features]
y = data[target_variable]

# 3. 训练SVM模型
svm_model = SVC(probability=True)
svm_model.fit(X, y)

# 保存模型
model_path = "D:\\Charging\\proposal20231001\\after1109_rev\\models\\trained_models_v3\\06_05_SVM_model_smoking_v3.pkl"
joblib.dump(svm_model, model_path)

# 4. 交叉验证
cv = StratifiedKFold(n_splits=10, random_state=42, shuffle=True)

# 5. 计算评估指标
accuracy_scores = []
f1_scores = []
roc_auc_scores = []
conf_matrix = np.zeros((2, 2))
precision_scores = []
recall_scores = []

for train_idx, test_idx in cv.split(X, y):
    X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

    svm_model.fit(X_train, y_train)
    y_pred = svm_model.predict(X_test)
    y_pred_proba = svm_model.predict_proba(X_test)[:, 1]

    # 计算各项指标
    accuracy_scores.append(accuracy_score(y_test, y_pred))
    f1_scores.append(f1_score(y_test, y_pred))
    roc_auc_scores.append(roc_auc_score(y_test, y_pred_proba))
    conf_matrix += confusion_matrix(y_test, y_pred)
    precision_scores.append(precision_score(y_test, y_pred))
    recall_scores.append(recall_score(y_test, y_pred))

# 打印评估指标的平均值
print("Average Accuracy:", np.mean(accuracy_scores))
print("Average F1 Score:", np.mean(f1_scores))
print("Average AUC of ROC:", np.mean(roc_auc_scores))

# 打印总体混淆矩阵
tn, fp, fn, tp = conf_matrix.ravel()
print("\n总体混淆矩阵：")
print(f"TP: {tp} | FP: {fp}")
print(f"FN: {fn} | TN: {tn}")

print("Average Precision:", np.mean(precision_scores))
print("Average Recall:", np.mean(recall_scores))


# 6. 打印模型配置参数
print("Model Configuration Parameters:")
for param, value in svm_model.get_params().items():
    print(f"{param}: {value}")

